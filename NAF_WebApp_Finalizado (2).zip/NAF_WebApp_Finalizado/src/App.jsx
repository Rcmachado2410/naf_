import React from 'react'
import './index.css'

export default function App() {
  return (
    <div className="container">
      <h1>Sou a <span className="highlight">NAF</span>, sua assistente virtual</h1>
      <p>Selecione uma ação e deixe comigo 💜</p>
      <div className="buttons">
        {[
          "📩 Analisar E-mails",
          "🗓️ Lembrete de Agenda",
          "👥 Analisar CEO",
          "🌍 Analisar OMS",
          "🇺🇸 Praticar Inglês",
          "⚙️ Automatizar Tarefas",
          "🧠 Aprender Nova Tarefa"
        ].map((cmd, i) => (
          <button key={i}>{cmd}</button>
        ))}
      </div>
    </div>
  )
}